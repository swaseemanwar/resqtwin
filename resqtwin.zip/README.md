# ResQTwin: Disaster Area Digital Twin (PS7)

ResQTwin is a MATLAB, Simscape, and Stateflow digital twin prototype that physically simulates how rising pore water pressure inside soil affects slope stability, uses AI to forecast impending slope failure, and dynamically manages road safety status.

---

## 🛠 Prerequisites & Required Toolboxes

Tested on **MATLAB R2024b / R2025a**. Ensure the following toolboxes are installed:
- MATLAB & Simulink
- Simscape
- Simscape Multibody
- Simscape Fluids
- Deep Learning Toolbox (LSTM Inference)
- Stateflow

---

## 📁 Repository Structure

```text
resqtwin/
├── FlashFlood.mat                  # Dynamic flash flood pressure dataset
├── GentleMonsoon.mat               # Dynamic monsoon pressure dataset
├── predictiveModel.mat             # Pre-trained LSTM neural network model
├── Rainfall_Pressure_Scenario.mat  # 60-second baseline rainfall pressure surge
├── RainScenarios.mat               # Combined rain scenario dataset
├── ResQTwin_Plant.slx              # Core Hydro-Mechanical, AI & Stateflow Co-Simulation Model
├── resqtwin.prj                    # MATLAB Project environment file (Auto-configures paths)
├── README.md                       # Project documentation
├── CONTRIBUTING.md                 # Project contribution guidelines
├── scripts/                        # Project automation scripts
│   └── trainPredictiveAI.m         # LSTM network training routine
├── simulation/                     # Custom MATLAB packages and scenarios
│   └── matlab/
│       └── +resqtwin/
│           └── +scenarios/
│               └── basicLandslide.m
└── resources/                      # MATLAB Project metadata

